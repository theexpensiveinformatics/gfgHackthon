package error404.gfg.healthcare;

public class Model {
    String img;
    String headline;
    String description;
    String publisher;
    String time;
    String weblink;
    String ytlink;


    public String getImg() {
        return this.img;
    }
    public String getHeadline() {
        return this.headline;
    }
    public String getDescription() {
        return this.description;
    }
    public String getTime() {
        return this.time;
    }
    public String getPublisher() {
        return this.publisher;
    }
    public String getWeblink() {
        return this.weblink;
    }
    public String getYtlink() {
        return this.ytlink;
    }

    public void setImg(String img) {
        this.img = img;
    }
    public void setHeadline(String headline) {
        this.headline = headline;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public void setWeblink(String weblink) {
        this.weblink = weblink;
    }
    public void setYtlink(String ytlink) {
        this.ytlink = ytlink;
    }



    public Model()
    {

    }
}
