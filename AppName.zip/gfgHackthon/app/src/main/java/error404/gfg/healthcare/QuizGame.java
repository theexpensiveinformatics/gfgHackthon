package error404.gfg.healthcare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class QuizGame extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_game);
    }
}